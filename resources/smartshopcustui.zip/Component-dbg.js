sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("smartshopcustui.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);